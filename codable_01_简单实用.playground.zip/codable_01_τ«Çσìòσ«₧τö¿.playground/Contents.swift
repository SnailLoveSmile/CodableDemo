import UIKit

let response = """
{
    "title": "2019 is a wonderfull year",
    "series": "what`s new in swift 4",
    "created_by": "doubleTian",
    "type": "free",
    "created_at": "2018-08-23T01:43:42Z",
    "duration": 6.5,
    "all_time": "NaN",
    "origin": "Ym94dWVpby5jb20=",
    "url": "boxueio.com"
}
"""
enum EpisodeType: String, Codable {
    case free
    case paid
}
struct Episode: Codable {


    var title: String
    var series: String
    var createdBy: String
    var type: EpisodeType
    var createdAt: Date
    var duration: Float
    var allTime: Float
    var origin: Data
    var url: URL
}

let data = response.data(using: String.Encoding.utf8)!
let decoder = JSONDecoder()
decoder.keyDecodingStrategy = JSONDecoder.KeyDecodingStrategy.convertFromSnakeCase
decoder.dateDecodingStrategy = .iso8601
decoder.dataDecodingStrategy = .base64
decoder.nonConformingFloatDecodingStrategy = JSONDecoder.NonConformingFloatDecodingStrategy.convertFromString(positiveInfinity: "+Infinity", negativeInfinity: "-Infinity", nan: "NaN");
let episode = try decoder.decode(Episode.self, from: data)

let data_base64 = String(data: episode.origin, encoding: .utf8)
print(data_base64 ?? "no data")
dump(episode)
let encoder = JSONEncoder()
encoder.outputFormatting = JSONEncoder.OutputFormatting.prettyPrinted;
encoder.keyEncodingStrategy = JSONEncoder.KeyEncodingStrategy.convertToSnakeCase
encoder.dataEncodingStrategy = .base64
encoder.dateEncodingStrategy = .iso8601
encoder.nonConformingFloatEncodingStrategy = JSONEncoder.NonConformingFloatEncodingStrategy.convertToString(positiveInfinity: "+Infinity", negativeInfinity: "-Infinity", nan: "NaN");
let jsonData = try! encoder.encode(episode)
let jsonString = String(data: jsonData, encoding: String.Encoding.utf8)




