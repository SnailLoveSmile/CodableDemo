import UIKit




enum EpisodeType: String, Codable {
    case free
    case paid
}
struct Episode: Codable {


    var title: String
    var series: String
    var createdBy: String
    var type: EpisodeType
    var createdAt: Date
    var duration: Float
    var allTime: Float
    var origin: Data
    var url: URL
}



let decoder = JSONDecoder()
decoder.dateDecodingStrategy = .iso8601
decoder.keyDecodingStrategy = .convertFromSnakeCase
decoder.nonConformingFloatDecodingStrategy = .convertFromString(positiveInfinity: "+Infinity", negativeInfinity: "-Infinity", nan: "NaN")
decoder.dataDecodingStrategy = JSONDecoder.DataDecodingStrategy.base64


let response1 = """
{
"list":[
{
"title": "2019 is a wonderfull year",
"series": "what`s new in swift 4",
"created_by": "doubleTian",
"type": "free",
"created_at": "2018-08-23T01:43:42Z",
"duration": 6.5,
"all_time": "NaN",
"origin": "Ym94dWVpby5jb20=",
"url": "boxueio.com"
}
]
}
"""

struct EpisodeList: Codable {
    let list: [Episode]
}
var respondData1 = response1.data(using: .utf8)!
let respondList = try decoder.decode(EpisodeList.self, from: respondData1)
//dump(respondList)


let response2 = """
[
{
"title": "2019 is a wonderfull year",
"series": "what`s new in swift 4",
"created_by": "doubleTian",
"type": "free",
"created_at": "2018-08-23T01:43:42Z",
"duration": 6.5,
"all_time": "NaN",
"origin": "Ym94dWVpby5jb20=",
"url": "boxueio.com"
}
]
"""

var respondArrayData = response2.data(using: .utf8)!
let respondArray = try decoder.decode([Episode].self, from: respondArrayData)
//dump(respondArray)

let response3 = """
[
    {
    "episode2":
            {
                "title": "2019 is a wonderfull year",
                "series": "what`s new in swift 4",
                "created_by": "doubleTian",
                "type": "free",
                "created_at": "2018-08-23T01:43:42Z",
                "duration": 6.5,
                "all_time": "NaN",
                "origin": "Ym94dWVpby5jb20=",
                "url": "boxueio.com"
            }
    }
]
"""

let respond3Data = response3.data(using: .utf8)!
let respond3_model = try decoder.decode([Dictionary<String,Episode>].self, from: respond3Data)
//dump(respond3_model)


struct Episode2List:Codable {
    let episode2:Episode
}

let episode2List = try decoder.decode([Episode2List].self, from: respond3Data)
//print(episode2List.first?.episode2.createdBy ?? "no data")



let response4 = """
{
"meta":
{
"total_exp":1000,
"level":"beginner",
"total_duration":120
},
"list":
[
{
"title": "2019 is a wonderfull year",
"series": "what`s new in swift 4",
"created_by": "doubleTian",
"type": "free",
"created_at": "2018-08-23T01:43:42Z",
"duration": 6.5,
"all_time": "NaN",
"origin": "Ym94dWVpby5jb20=",
"url": "boxueio.com"
}
]
}
"""
struct EpisodeMeta:Codable {
    var totalExp:Int
    var level:EpisodeLevel
    var totalDuration:Int

    enum EpisodeLevel:String, Codable {
        case beginner
        case intermediate
        case advanced
    }
}
struct EpisodePage:Codable {
    var meta:EpisodeMeta
    var list: [Episode]
}

let jsonData4 = response4.data(using: .utf8)!
let page = try decoder.decode(EpisodePage.self, from: jsonData4)
dump(page)
