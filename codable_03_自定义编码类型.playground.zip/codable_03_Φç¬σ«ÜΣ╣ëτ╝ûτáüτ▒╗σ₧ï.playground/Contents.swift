import UIKit
struct Episode: Codable {
    var title: String
    var creatAt: Date
    var comment: String?//默认使用IfPresent编码的,对于可选值类型进行要强制用encode进行编码进去
    var slices: [Float] = [0.25, 0.5, 0.75]
}
extension Episode {
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
       try container.encode(title, forKey: .title)
        try container.encode(creatAt, forKey: .creatAt)
        try container.encode(comment, forKey: .comment)
        var sliceContainer =  container.nestedUnkeyedContainer(forKey: .slices)
        try slices.forEach { slice in
           try sliceContainer.encode("\(100 * slice)%")
        }

    }
}



let episode = Episode(title: "How to parse a JSON - 003", creatAt: Date(), comment: nil,slices: [0.25, 0.5, 0.75])
let encoder = JSONEncoder()
encoder.outputFormatting = .prettyPrinted
encoder.dateEncodingStrategy = .custom({ (date, encoder) in

    let formatter = DateFormatter()
    formatter.dateFormat = "yyyy-MM-dd hh:mm:ss"
    let dateString = formatter.string(from: date)
    var container = encoder.singleValueContainer()
    try container.encode(dateString)
})

let data = try encoder.encode(episode)
print(String(data: data, encoding: .utf8) ?? "no data")









