import UIKit
struct Episode: Codable {
    var title: String
    var createdAt: Date
    var duration: Int
    var comment: String?
    var slices:[Float]


    init(title: String, createdAt:Date, comment: String?, duration: Int, slices: [Float]) {
        self.title = title
        self.createdAt = createdAt
        self.comment = comment
        self.duration = duration
        self.slices = slices
    }

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        let title = try container.decode(String.self, forKey: .title)
        let createdAt = try container.decode(Date.self, forKey: .createdAt)
        let duration = try container.decode(Int.self, forKey: .duration)
        let comment = try container.decodeIfPresent(String.self, forKey: .comment)
        var sliceContainer = try container.nestedUnkeyedContainer(forKey: .slices)
        var slices = [Float]()
        while !sliceContainer.isAtEnd {
            let slice = try sliceContainer.decode(Float.self)
            slices.append(slice)
        }
        self.init(title: title, createdAt: createdAt, comment: comment, duration: duration, slices: slices)
    }

}


let response = """
{
"title": "2019 is a wonderfull year",
"createdAt": "2018-08-23 01:43:42 CST",
"comment": "null",
"duration": 500,
"slices":
        [125, 250, 375]
}
"""

let data = response.data(using: .utf8)!
let decoder = JSONDecoder()
decoder.dateDecodingStrategy = .custom {
    let data = try $0.singleValueContainer().decode(String.self)
    let formmater = DateFormatter()
    formmater.dateFormat = "yyyy-MM-dd hh:mm:sszzz"
    return formmater.date(from: data)!
}
let episode = try! decoder.decode(Episode.self, from: data)
dump(episode)




struct Episode2: Codable {
    var title: String
    var createdAt: Date
    var comment: String?
    var duration: Int
    var slices: [Float]
    enum CodingKeys:String, CodingKey {
        case title
        case createdAt
        case comment
        case meta
    }


    init(title: String, createdAt:Date, comment: String?, duration: Int, slices: [Float]) {
        self.title = title
        self.createdAt = createdAt
        self.comment = comment
        self.slices = slices
        self.duration = duration
    }

    enum MetaCodingKeys:String, CodingKey {
        case duration
        case slices
    }

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        let title = try container.decode(String.self, forKey: .title)
        let createdAt = try container.decode(Date.self, forKey: .createdAt)
        let comment = try container.decodeIfPresent(String.self, forKey: .comment)


        let metaContainer = try container.nestedContainer(keyedBy: MetaCodingKeys.self, forKey: .meta)
        let duration = try metaContainer.decode(Int.self, forKey: .duration)
        var sliceContainer = try metaContainer.nestedUnkeyedContainer(forKey: .slices)
        var slices = [Float]()
        while !sliceContainer.isAtEnd {
            let slice = try sliceContainer.decode(Float.self)
            slices.append(slice/Float(duration))
        }

        self.init(title: title, createdAt: createdAt, comment: comment, duration: duration, slices: slices)
    }

}
extension Episode2 {
    func encode(to encoder: Encoder) throws {

    }
}

let response2 = """
{
"title": "2019 is a wonderfull year",
"createdAt": "2018-08-23 01:43:42 CST",
"comment": "null",
"meta":
{
"duration": 500,
"slices":[125, 250, 375]
}
}
"""
let data2 = response2.data(using: .utf8)!
let decoder2 = JSONDecoder()
decoder2.dateDecodingStrategy = .custom {
    let data = try $0.singleValueContainer().decode(String.self)
    let formmater = DateFormatter()
    formmater.dateFormat = "yyyy-MM-dd hh:mm:sszzz"
    return formmater.date(from: data)!
}
let episode2 = try! decoder2.decode(Episode2.self, from: data2)
dump(episode2)
