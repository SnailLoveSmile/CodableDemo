import UIKit

class Point2D:Codable {
    var x = 0.0
    var y = 0.0
   private enum CodingKeys: String,CodingKey {
        case x
        case y
    }
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
       try container.encode(x, forKey: .x)
        try container.encode(y, forKey: .y)
    }
}
class Point3D: Point2D {
    var z = 0.0
   private enum CodingKeys: String,CodingKey {
        case z
        case point_2d
    }
    override func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try super.encode(to: container.superEncoder(forKey: .point_2d))
        try container.encode(z, forKey: .z)

    }
}

func encode<T: Codable>(of model: T) throws {
    let encoder = JSONEncoder()
    encoder.outputFormatting = .prettyPrinted
    let data = try encoder.encode(model)
    print(String(data: data, encoding: .utf8) ?? "no data")
}

var pt = Point3D()
pt.x = 1
pt.y = 1
pt.z = 1
try encode(of: pt)
var pt2 = Point2D()
pt2.x = 2
pt2.y = 2
try encode(of: pt2)
